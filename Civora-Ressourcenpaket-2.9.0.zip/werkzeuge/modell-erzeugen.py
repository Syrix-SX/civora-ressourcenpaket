#!/usr/bin/env python3
"""Civora Ressourcenpaket: Item-Modelle aus Texturen erzeugen.

So bekommt ein Item ein eigenes Aussehen:
  1. 16x16-Textur (PNG) nach  assets/civora/textures/item/<id>.png  legen  (<id> = Name in items.yml, z.B. wipfelschneider)
  2. Dieses Skript im Paket-Ordner ausfuehren:   python3 werkzeuge/modell-erzeugen.py
     -> legt assets/civora/models/item/<id>.json und assets/civora/items/<id>.json an (nur wo noch keine existieren)
  3. In items.yml beim Item die Zeile eintragen:   item-model: "civora:<id>"
  4. Paket neu zippen, SHA1 neu berechnen (sha1sum), in config.yml ressourcenpaket.url + sha1 eintragen.
Ohne diese Zeile in items.yml zeigt das Item sein normales Minecraft-Aussehen (so liefern wir 2.9.0 aus).
"""
import json, os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
tex = os.path.join(root, "assets/civora/textures/item")
mod = os.path.join(root, "assets/civora/models/item")
dfn = os.path.join(root, "assets/civora/items")
os.makedirs(mod, exist_ok=True); os.makedirs(dfn, exist_ok=True)
neu = []
for f in sorted(os.listdir(tex)):
    if not f.endswith(".png"): continue
    i = f[:-4]
    if "_side" in i or "_end" in i: continue          # Crate-Seitenflaechen
    mp, dp = os.path.join(mod, i + ".json"), os.path.join(dfn, i + ".json")
    if os.path.exists(dp): continue
    if not os.path.exists(mp):
        json.dump({"parent": "minecraft:item/generated", "textures": {"layer0": "civora:item/" + i}}, open(mp, "w"), indent=1)
    json.dump({"model": {"type": "minecraft:model", "model": "civora:item/" + i}}, open(dp, "w"), indent=1)
    neu.append(i)
print(len(neu), "neue Modelle:", ", ".join(neu) or "-")
for i in neu: print('  items.yml ->', i, ':  item-model: "civora:%s"' % i)

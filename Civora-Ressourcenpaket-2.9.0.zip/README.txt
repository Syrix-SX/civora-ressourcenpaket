Civora SMP Ressourcenpaket (für Minecraft 26.1 bis 26.3, pack.mcmeta: min_format [84,0], max_format 97)
Symbole (Sidebar/Chat):  Logo,  Welt,  Geld,  Grundstueck,  Spieler,  Votecoins, - Jobs
Item-Skins (custom_model_data): 1001-1003 Rubin (Spitzhacke, Schwert, Axt), 1011-1013 Smaragd.
Skin "Farbig" (Schwert): Modell civora:farbig_sword, Farbe kommt aus custom_model_data -> colors[0] (RGB-Dialog im Spiel).
Spezial-Items: assets/civora/items/<id>.json + models + textures (Leuchtstaub, Barrieren Glas, Teppich, Flaschen, ...),
im Spiel gesetzt über items.yml -> item-model: "civora:<id>".

Neu in 2.8.0: Crate-Koepfe (assets/civora/items|models|textures: crate_beginner, crate_expert, crate_luxus, crate_plot, crate_prestige),
Todeskiste (todeskiste) und ein Civora-Design fuer alle Kisten-Menues (assets/minecraft/textures/gui/container/generic_54.png).
Die Koepfe werden per item_model gesetzt; wer lieber echte Kopf-Texturen nutzt, traegt kopf-textur in kisten.yml bzw. grab.kopf-textur in config.yml ein.

Neu in 2.9.0: Pflicht-Paket (config.yml -> ressourcenpaket.pflicht), Logo als feste Schrift-Glyphe  (Sidebar/Tabliste, feste Groesse).
Die ~220 neuen Items aus den Crates (siehe werkzeuge/ITEMS-OHNE-MODELL.txt) haben noch KEINE eigene Textur und sehen deshalb wie ihr
Minecraft-Grundmaterial aus. Eigene Texturen: werkzeuge/modell-erzeugen.py (Anleitung im Skript). Haustiere/Paletten: gleiche Methode.
